setwd("C:\\Users\\ADMIN\\Desktop\\IT24102046_Lab6")

n <- 50
p <- 0.85
prob_at_least_47 <- sum(dbinom(47:50, size = n, prob = p))
cat("Probability that at least 47 students passed:", round(prob_at_least_47, 4))


lambda <- 12
prob_exactly_15 <- dpois(15, lambda)
cat("Probability of receiving exactly 15 calls:", round(prob_exactly_15, 4))

