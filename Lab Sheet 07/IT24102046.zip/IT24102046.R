setwd("C:\\Users\\ADMIN\\Desktop\\IT24102046_Lab7")

a <- 0
b <- 40
x1 <- 10
x2 <- 25
prob_uniform <- punif(x2, min = a, max = b) - punif(x1, min = a, max = b)
cat("probability that the train arrives between 8:10 a.m. and 8:25
 a.m.:", round(prob_uniform, 4))


lambda <- 1/3
x <- 2
prob_exponential <- pexp(x, rate = lambda)
cat("probability that an update will take at most 2 hours:", round(prob_exponential, 4))


mean_iq <- 100
sd_iq <- 15

prob_iq_above_130 <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
cat("Probability that IQ > 130:", round(prob_iq_above_130, 4))


iq_95th_percentile <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
cat("IQ score at 95th percentile:", round(iq_95th_percentile, 2))

    
    